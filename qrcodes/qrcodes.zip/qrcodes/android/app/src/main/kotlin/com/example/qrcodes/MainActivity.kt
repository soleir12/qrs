package com.example.qrcodes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
